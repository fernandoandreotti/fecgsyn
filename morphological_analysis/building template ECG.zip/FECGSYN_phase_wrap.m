function phase = FECGSYN_phase_wrap(peaks,N)
%
% phase = phase_wrap(peaks,N)
% ECG phase calculation from a given set of R-peaks.
%
% inputs
%       peaks: vector of R-peak pulse train
%       N:      number of samples in ecg signal
% 
% output:
%       phase: the calculated phases ranging from -pi to pi. The R-peaks are
%              located at phase = 0.
%
%
% Open Source ECG Toolbox, version 1.0, November 2006
% Released under the GNU General Public License
% Copyright (C) 2006  Reza Sameni
% Sharif University of Technology, Tehran, Iran -- LIS-INPG, Grenoble, France
% reza.sameni@gmail.com
% 
% Last updated : 27-03-2014, Joachim Behar

phasepos = zeros(1,N);

I = peaks;
for i = 1:length(I)-1;
    m = I(i+1) - I(i);
    phasepos(I(i)+1:I(i+1)) = 2*pi/m : 2*pi/m : 2*pi;
end
m = I(2) - I(1);
L = length(phasepos(1:I(1)));
phasepos(1:I(1)) = 2*pi-(L-1)*2*pi/m:2*pi/m:2*pi;

m = I(end) - I(end-1);
L = length(phasepos(I(end)+1:end));
phasepos(I(end)+1:end) = 2*pi/m:2*pi/m:L*2*pi/m;

phasepos = mod(phasepos,2*pi);

phase = phasepos; 
I = find(phasepos>pi);
phase(I) = phasepos(I) - 2*pi;
