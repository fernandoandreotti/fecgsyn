function [ecgme,ecgsd] = FECGSYN_templatebuild3(ecg,qrs,fs,teta,debug)
% generate a template ecg by stacking ecg cycles (no phase mapping). The
% cycles with similar RR interval are selected and the the cycles that
% match with each other are selected. Thus this function
% provides a mean ECG cycle that will exclude the bad quality cycles and 
% build the ecg template out of the cycles that have a similar RR
% interval. Advantages of this functions is that it is fast, works in the
% time domain and is pretty robust for excluding all the bad quality cycles
% from the ones used to build the template. However it only handles one
% mode i.e. one ECG cycle morphology.
%
% inputs
%   ecg:        ecg signal
%   qrs:        qrs location [in samples]
%   fs:         sampling frequency [Hz]
%   teta:       phase shift (use to shift to the left for ecgme 
%               construction in order to get the whole T-wave) [in rad]
%   debug:      debug mode (0,1,2)
%
% outputs
%   ecgme:      template cycle
%   ecgsd:      standard deviation (used to parametrise the EKF covariance matrix)
%
% FECGSYN, version 1.0, March 2014
% Released under the GNU General Public License
%
% Copyright (C) 2014  Joachim Behar & Fernando Andreotti
% Oxford university, Intelligent Patient Monitoring Group - Oxford 2014
% joachim.behar@eng.ox.ac.uk, fernando.andreotti@mailbox.tu-dresden.de
%
% Last updated : 18-08-2014, Joachim
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
% prepare

% == constants
qrs_cut = qrs(2:end-2); % remove first and last QRS to account for border effects
TOL_RR = 0.015; % cycles that are TOL_RR different from the min RR are excluded - UPDATE ME DEPENDING ON APPLICATION
NB_CYC = length(qrs_cut); % number of cycles
RR = diff(qrs_cut)/fs;
RRm = median(RR); % median RR interval
window = round((RRm/2)*fs);
SHIFTC = teta/(2*pi); % so that the template is not centered on the QRS location
thres = 0.85;  % - UPDATE ME DEPENDING ON APPLICATION

% == Only select beat with similar RR interval (i.e. HR)
ind = 0;
while sum(ind)<ceil(NB_CYC/2)
    ind = abs(RR-RRm)<TOL_RR;
    TOL_RR = TOL_RR + 0.010; % you can vary the tolerance
end

% == build template ECG
M = arrayfun(@(x) ecg(1,x-(window + round(2*window*SHIFTC)):x+(window - ...
    round(2*window*SHIFTC)))',qrs_cut,'UniformOutput',false); % creates a maternal beat matrix
M = cell2mat(M); % converting cell output to array form
M(:,~ind) = []; % remove the cycles with too different RR from the median
avgbeat = median(M,2)'; % evaluate the average beat (before prunning bad quality cycles)
                        % median is used here to naturally remove the outliers and obtain 
                        % a 'gross' average ECG cycle 

% == exclude low correlating beats
NB_CYC = size(M,2);
match = zeros(NB_CYC,1);
coeff = zeros(NB_CYC,1);

for cc=1:NB_CYC
    [match(cc),coeff(cc)] = FECGSYN_crosscor(avgbeat,M(:,cc),thres);
end

if sum(match)>NB_CYC/2
    M = M(:,find(match));
else % if not enough cycles then just take the best
    ccneeded = median(coeff);
    M = M(:,coeff>ccneeded);            
end

ecgme = mean(M,2); % ecgme built from mean of selected beats
ecgme = ecgme-mean(ecgme(1:round(fs*0.05))); % adjust ecgme to isoelectric 
ecgsd = std(M,0,2); % standard deviation over the cycle

% == debug area
if debug>=1 
    fprintf('Number of cycles detected: %f \n',length(qrs_cut));
    fprintf('Number of cycles selected before corr: %f \n',sum(ind));
    fprintf('Number of cycles selected after corr: %f \n',size(M,2));
    if isnan(ecgme); disp('WARNING: Not able to produce ecgme, low correlation'); end  
end

if debug>=2
    LINEWIDTH = 2;
    FONTSIZE = 20;
    NB_BINS = 2*window+1;
    tm = 1/fs:1/fs:NB_BINS/fs;
    plot(tm,ecgme,'LineWidth',LINEWIDTH);
    xlabel('Number [samples]');
    ylabel('Amplitude [NU]');
    set(findall(gcf,'type','text'),'fontSize',FONTSIZE);
end

end













