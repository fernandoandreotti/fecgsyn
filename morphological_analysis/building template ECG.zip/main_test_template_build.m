% main scipt test templat build
%
% method 1: Phase based: Julien mode selection
% method 2: Phase based: RR check and build median
% method 3: Time based: RR check and remove the cycles that are uncorrelated with the mean
% method 4: Reza's phase one
%
%

clear all; clc;

path2ini = '/netshares/ipmprojects3/JB_Experimental_Data/2014.07_fecgsyn_simulations(2.0)';
path2ext = '/netshares/ipmprojects3/JB_Experimental_Data/simulated_data_template_construction';

addpath(path2ini);
addpath(path2ext);

recMixtureList = dir([path2ini '/*.mat']);
recExtractedList = dir([path2ext '/*.mat']);

fls_mix = arrayfun(@(x)x.name,recMixtureList,'UniformOutput',false);
fls_ext = arrayfun(@(x)x.name,recExtractedList,'UniformOutput',false);

fs = 250;
LINEWIDTH = 2;
F1 = zeros(6,1);

for rr=1:1:50
    disp(['Processing record: ' int2str(rr)]);
    
    % == load the residual signal
    [rec,met] = strtok(fls_ext(rr),'_');
    filename = rec{1}(4:end);
    trans = load(fls_ext{rr}); % load residual
    residual = trans.residual;
    
    % == load intial record that corresponds to this residual
    load(recMixtureList(str2double(filename)).name);
    refqrs = round(out.fqrs{1}/4);  % downsample to 250Hz
    
    % == look at what channel is the best
    for cc=1:6
        [F1(cc),~,~,~] = stats(refqrs/fs,trans.fqrs{cc}/fs,0.05);
    end
    [~,ind] = max(F1);
    resone = residual(ind,:); % selected residual
    
    % == now only select one minute
    resone = resone(1:fs*60);
    refqrs = refqrs(refqrs<fs*60);
    NB_SAMP = length(resone);
    
    % == test the different template construction methods
    [relevMode] = FECGSYN_templatebuild1(resone,refqrs,1); % Phase based: Julien mode selection
    [template2] = FECGSYN_templatebuild2(resone,refqrs,fs); % Phase based: RR check and build median
    [template3] = FECGSYN_templatebuild3(resone,refqrs,fs,-pi/3,[]); % Time based: RR check and remove the cycles that are uncorrelated with the mean
    [template4] = FECGSYN_templatebuild4(resone,refqrs);
    [template5] = FECGSYN_templatebuild5(resone,refqrs);
    
    template1 = relevMode.cycleMean;
    
    tm = 1/fs:1/fs:NB_SAMP/fs;
    subplot(2,2,1:2);
    plot(tm,resone); xlim([1 10]);
    legend('Residual signal TS_{pca}');
    subplot(223);
    plot(template1);
    hold on, plot(template2,'r');
    hold on, plot(template4,'c');
    hold on, plot(template5,'g');
    legend('method 1','method 2','method 4','method 5');
    xlim([1 length(template2)]);
    subplot(224);
    plot(template3,'k');
    legend('method 3');
    xlim([1 length(template3)]);
    
    saveas(gcf,int2str(rr),'png');
    close all;
end


%%
% Joachim playing with stuff on his laptop and not having access to is IBME
% machine!


















